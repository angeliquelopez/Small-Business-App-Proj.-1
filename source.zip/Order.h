#include <string>
using namespace std;


class Order 
{
  private:
    string proteinOptions[5] = { "Chicken", "Carnitas", "Steak", "Tofu", "Veggie"};
    double proteinPrices[5] = { 7.00, 8.00, 8.00, 7.00, 5.00};

    string beanOptions[2] = { "Pinto Beans","Black Beans"};
    double beanPrices[2] = { 1.00,1.00};

    string riceOptions[3] = {"White Rice", "Brown Rice", "Quinoa"};
    double ricePrice[3] = {1.00, 1.00, 2.00};

    string topOptions [7] = {"Stir Fry Veggies", "Lettuce", "Corn", "Cheese", "Pico de Gallo", "Sour Cream", "Guacamole"};
    double topPrice[7] = {1.00, 1.00, 1.00, 1.00, 1.00, 1.00, 2.00};

    public: 
      string getProteinOptions(int);
      double getProteinPrice(int);
      
      string getBeanOptions(int);
      double getBeanPrice(int);
      
      string getRiceOptions(int);
      double getRicePrice(int);
      
      string getTopOption(int);
      double getTopPrice(int);
};