#include "Order.h"
#include<string>
using namespace std;

      string Order::getProteinOptions(int i)
      {
        return proteinOptions[i];
      }
      double Order::getProteinPrice(int i)
      {
        return proteinPrices[i];
      }
      
      string Order::getBeanOptions(int i)
      {
        return beanOptions[i];
      }


      double Order::getBeanPrice(int i)
      {
          return beanPrices[i];
      }


      string Order::getRiceOptions(int i)
      {
        return riceOptions[i];
      }

      
      double Order::getRicePrice(int i)
      {
        return ricePrice[i];
      }

      
      string Order::getTopOption(int i)
      {
        return topOptions[i];
      }

      
      double Order::getTopPrice(int i)
      {
        return topPrice[i];
      }
